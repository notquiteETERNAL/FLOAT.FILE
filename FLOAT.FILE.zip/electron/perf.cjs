const { app } = require("electron");
const os = require("node:os");

const BOOST_INTERVAL = 15000;

// has to run before the app is ready
function applySwitches() {
  const { commandLine } = app;
  // windows covered by a game and background processes shouldn't get slowed down
  commandLine.appendSwitch("disable-features", "CalculateNativeWinOcclusion");
  commandLine.appendSwitch("disable-renderer-backgrounding");
  commandLine.appendSwitch("disable-background-timer-throttling");
  commandLine.appendSwitch("disable-backgrounding-occluded-windows");
}

// bumps the main process and every helper process (renderers, gpu) above normal apps
function boost() {
  for (const { pid } of app.getAppMetrics()) {
    try {
      os.setPriority(pid, os.constants.priority.PRIORITY_HIGH);
    } catch {}
  }
}

function start() {
  boost();
  // chromium can restart its helper processes, so catch the new ones too
  setInterval(boost, BOOST_INTERVAL).unref();
}

module.exports = { applySwitches, boost, start };
