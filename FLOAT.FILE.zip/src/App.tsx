import { useEffect, useRef, useState } from "react";
import logo from "./assets/float-file-logo.png";

const GRIPS = ["n", "s", "e", "w", "ne", "nw", "se", "sw"];

function Icon({ children, filled = false }: { children: React.ReactNode; filled?: boolean }) {
  return (
    <svg
      aria-hidden="true"
      viewBox="0 0 24 24"
      fill={filled ? "currentColor" : "none"}
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {children}
    </svg>
  );
}

const PinIcon = ({ filled }: { filled: boolean }) => (
  <Icon filled={filled}>
    <path d="M14.8 4.1 20 9.3l-3.2 1.3-3.5 3.5-1 4.6-1.2 1.2-3.3-5.7-4.5-2.6 1.2-1.2 4.6-1 3.5-3.5 1.2-3.1 1-1Z" />
    <path d="m9.1 14.1-5 5" />
  </Icon>
);

const AddIcon = () => (
  <Icon>
    <path d="M12 5v14M5 12h14" />
  </Icon>
);

const MinimizeIcon = () => (
  <Icon>
    <path d="M6 12h12" />
  </Icon>
);

const CloseIcon = () => (
  <Icon>
    <path d="m6 6 12 12M18 6 6 18" />
  </Icon>
);

export default function App() {
  const api = window.floatFile;
  const inputRef = useRef<HTMLInputElement>(null);
  const [isPinned, setIsPinned] = useState(true);
  const [isDragging, setIsDragging] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    api?.setPinned(isPinned);
  }, [api, isPinned]);

  useEffect(() => {
    let timer: number | undefined;
    const stopListening = api?.onError((message) => {
      setError(message);
      window.clearTimeout(timer);
      timer = window.setTimeout(() => setError(""), 4000);
    });
    return () => {
      stopListening?.();
      window.clearTimeout(timer);
    };
  }, [api]);

  useEffect(() => {
    const release = () => api?.dragStop();
    window.addEventListener("mouseup", release);
    window.addEventListener("blur", release);
    return () => {
      window.removeEventListener("mouseup", release);
      window.removeEventListener("blur", release);
    };
  }, [api]);

  const startDrag = (e: React.MouseEvent) => {
    if (e.button === 0) api?.dragStart();
  };

  const startResize = (dir: string) => (e: React.MouseEvent) => {
    if (e.button !== 0) return;
    e.stopPropagation();
    api?.resizeStart(dir);
  };

  return (
    <main
      className={`panel ${isDragging ? "is-dragging" : ""}`}
      onDragEnter={(e) => {
        e.preventDefault();
        setIsDragging(true);
      }}
      onDragOver={(e) => e.preventDefault()}
      onDragLeave={(e) => {
        if (!e.currentTarget.contains(e.relatedTarget as Node)) setIsDragging(false);
      }}
      onDrop={(e) => {
        // the preload script picks up the files, this just resets the highlight
        e.preventDefault();
        setIsDragging(false);
      }}
    >
      <header className="toolbar">
        <div className="brand" onMouseDown={startDrag}>
          <img className="brand-logo" src={logo} alt="" draggable={false} />
          <strong>FLOAT.FILE</strong>
        </div>
        <div className="drag-spacer" onMouseDown={startDrag} />

        <div className="controls">
          <button
            className={`pin-control ${isPinned ? "is-active" : ""}`}
            type="button"
            aria-pressed={isPinned}
            title={isPinned ? "Files stay on top" : "Files act like normal windows"}
            onClick={() => setIsPinned((current) => !current)}
          >
            <PinIcon filled={isPinned} />
            <span>{isPinned ? "Pinned" : "Pin"}</span>
          </button>
          <button className="icon-btn" type="button" title="Minimize" onClick={() => api?.minimize()}>
            <MinimizeIcon />
          </button>
          <button className="icon-btn close" type="button" title="Close" onClick={() => api?.close()}>
            <CloseIcon />
          </button>
        </div>
      </header>

      <section className="stage">
        <button className="media-picker" type="button" onClick={() => inputRef.current?.click()}>
          <span className="add-icon">
            <AddIcon />
          </span>
          <span className="picker-text">
            <strong>{isDragging ? "Drop to float" : "Select or drop files"}</strong>
            <small>Any file type · opens as a floating window</small>
          </span>
        </button>
        {error && <p className="error-message">{error}</p>}
      </section>

      <input ref={inputRef} className="visually-hidden" type="file" multiple />

      {GRIPS.map((dir) => (
        <div key={dir} className={`grip grip-${dir}`} onMouseDown={startResize(dir)} />
      ))}
    </main>
  );
}
