import { useEffect, useRef, useState } from "react";
import logo from "./assets/float-file-logo.png";

const SPOTS = [
  { id: "center", title: "Center of the screen", x: 9.5, y: 10 },
  { id: "top-left", title: "Top left corner", x: 5, y: 7 },
  { id: "top-right", title: "Top right corner", x: 14, y: 7 },
  { id: "bottom-left", title: "Bottom left corner", x: 5, y: 13 },
  { id: "bottom-right", title: "Bottom right corner", x: 14, y: 13 },
];

const STEP = 5;

const GRIPS = ["n", "s", "e", "w", "ne", "nw", "se", "sw"];

function Icon({ children, filled = false }: { children: React.ReactNode; filled?: boolean }) {
  return (
    <svg
      aria-hidden="true"
      viewBox="0 0 24 24"
      fill={filled ? "currentColor" : "none"}
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {children}
    </svg>
  );
}

const PinIcon = ({ filled }: { filled: boolean }) => (
  <Icon filled={filled}>
    <path d="M14.8 4.1 20 9.3l-3.2 1.3-3.5 3.5-1 4.6-1.2 1.2-3.3-5.7-4.5-2.6 1.2-1.2 4.6-1 3.5-3.5 1.2-3.1 1-1Z" />
    <path d="m9.1 14.1-5 5" />
  </Icon>
);

const AddIcon = () => (
  <Icon>
    <path d="M12 5v14M5 12h14" />
  </Icon>
);

const SpotIcon = ({ x, y }: { x: number; y: number }) => (
  <svg aria-hidden="true" viewBox="0 0 24 24">
    <rect x="3" y="5" width="18" height="14" rx="2.5" fill="none" stroke="currentColor" strokeWidth="1.6" />
    <rect x={x} y={y} width="5" height="4" rx="1" fill="currentColor" />
  </svg>
);

const PlusIcon = AddIcon;

const MinusIcon = () => (
  <Icon>
    <path d="M5 12h14" />
  </Icon>
);

const MinimizeIcon = () => (
  <Icon>
    <path d="M6 12h12" />
  </Icon>
);

const CloseIcon = () => (
  <Icon>
    <path d="m6 6 12 12M18 6 6 18" />
  </Icon>
);

export default function App() {
  const api = window.floatFile;
  const inputRef = useRef<HTMLInputElement>(null);
  const [isPinned, setIsPinned] = useState(true);
  const [isDragging, setIsDragging] = useState(false);
  const [error, setError] = useState("");
  const [active, setActive] = useState({ has: false, opacity: 100 });
  const [opacityText, setOpacityText] = useState("100");

  useEffect(() => {
    api?.setPinned(isPinned);
  }, [api, isPinned]);

  useEffect(() => {
    let timer: number | undefined;
    const stopListening = api?.onError((message) => {
      setError(message);
      window.clearTimeout(timer);
      timer = window.setTimeout(() => setError(""), 4000);
    });
    return () => {
      stopListening?.();
      window.clearTimeout(timer);
    };
  }, [api]);

  useEffect(() => {
    void api?.getActive().then(setActive);
    return api?.onActive(setActive);
  }, [api]);

  useEffect(() => {
    setOpacityText(String(active.opacity));
  }, [active.opacity]);

  useEffect(() => {
    const release = () => api?.dragStop();
    window.addEventListener("mouseup", release);
    window.addEventListener("blur", release);
    return () => {
      window.removeEventListener("mouseup", release);
      window.removeEventListener("blur", release);
    };
  }, [api]);

  const startDrag = (e: React.MouseEvent) => {
    if (e.button === 0) api?.dragStart();
  };

  const changeOpacity = (value: number) => {
    api?.setOpacity(Math.min(100, Math.max(0, value)));
  };

  const onOpacityInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    let digits = e.target.value.replace(/\D/g, "").slice(0, 3);
    if (digits !== "") digits = String(Math.min(100, Number(digits)));
    setOpacityText(digits);
    if (digits !== "") changeOpacity(Number(digits));
  };

  const startResize = (dir: string) => (e: React.MouseEvent) => {
    if (e.button !== 0) return;
    e.stopPropagation();
    api?.resizeStart(dir);
  };

  return (
    <main
      className={`panel ${isDragging ? "is-dragging" : ""}`}
      onDragEnter={(e) => {
        e.preventDefault();
        setIsDragging(true);
      }}
      onDragOver={(e) => e.preventDefault()}
      onDragLeave={(e) => {
        if (!e.currentTarget.contains(e.relatedTarget as Node)) setIsDragging(false);
      }}
      onDrop={(e) => {
        // the preload script picks up the files, this just resets the highlight
        e.preventDefault();
        setIsDragging(false);
      }}
    >
      <header className="toolbar">
        <div className="brand" onMouseDown={startDrag}>
          <img className="brand-logo" src={logo} alt="" draggable={false} />
          <strong>FLOAT.FILE</strong>
        </div>
        <div className="drag-spacer" onMouseDown={startDrag} />

        <div className="controls">
          <button
            className={`pin-control ${isPinned ? "is-active" : ""}`}
            type="button"
            aria-pressed={isPinned}
            title={isPinned ? "Files stay on top" : "Files act like normal windows"}
            onClick={() => setIsPinned((current) => !current)}
          >
            <PinIcon filled={isPinned} />
            <span>{isPinned ? "Pinned" : "Pin"}</span>
          </button>
          <button className="icon-btn" type="button" title="Minimize" onClick={() => api?.minimize()}>
            <MinimizeIcon />
          </button>
          <button className="icon-btn close" type="button" title="Close" onClick={() => api?.close()}>
            <CloseIcon />
          </button>
        </div>
      </header>

      <section className="stage">
        <button className="media-picker" type="button" onClick={() => inputRef.current?.click()}>
          <span className="add-icon">
            <AddIcon />
          </span>
          <span className="picker-text">
            <strong>{isDragging ? "Drop to float" : "Select or drop files"}</strong>
            <small>Any file type · opens as a floating window</small>
          </span>
        </button>

        <button
          className="recent-btn"
          type="button"
          onClick={(e) => {
            const box = e.currentTarget.getBoundingClientRect();
            api?.showRecent(box.left, box.bottom + 4);
          }}
        >
          Recent files
        </button>

        <div className="tools">
          {SPOTS.map((spot) => (
            <button
              key={spot.id}
              className="icon-btn"
              type="button"
              title={spot.title}
              disabled={!active.has}
              onClick={() => api?.snap(spot.id)}
            >
              <SpotIcon x={spot.x} y={spot.y} />
            </button>
          ))}

          <div className="opacity-group">
            <button
              className="icon-btn"
              type="button"
              title="More opaque"
              disabled={!active.has}
              onClick={() => changeOpacity(active.opacity + STEP)}
            >
              <PlusIcon />
            </button>
            <label className="opacity-field" title="Opacity">
              <input
                value={opacityText}
                inputMode="numeric"
                maxLength={3}
                disabled={!active.has}
                onChange={onOpacityInput}
                onBlur={() => setOpacityText(String(active.opacity))}
                onKeyDown={(e) => e.key === "Enter" && e.currentTarget.blur()}
              />
              <span>%</span>
            </label>
            <button
              className="icon-btn"
              type="button"
              title="More transparent"
              disabled={!active.has}
              onClick={() => changeOpacity(active.opacity - STEP)}
            >
              <MinusIcon />
            </button>
          </div>
        </div>

        {error && <p className="error-message">{error}</p>}
      </section>

      <input ref={inputRef} className="visually-hidden" type="file" multiple />

      {GRIPS.map((dir) => (
        <div key={dir} className={`grip grip-${dir}`} onMouseDown={startResize(dir)} />
      ))}
    </main>
  );
}
