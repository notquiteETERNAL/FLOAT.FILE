/// <reference types="vite/client" />

interface Window {
  floatFile?: {
    setPinned: (pinned: boolean) => void;
    minimize: () => void;
    close: () => void;
    dragStart: () => void;
    resizeStart: (dir: string) => void;
    dragStop: () => void;
    ready: (width: number, height: number, lockAspect: boolean) => void;
    readText: () => Promise<{ text: string; truncated: boolean }>;
    onTogglePlay: (cb: () => void) => () => void;
    onError: (cb: (message: string) => void) => () => void;
  };
}
